# Machine-Learning
Course CSE 7343 - Southern Methodist University

Welcome !!!!

These were the class projects for the course 'Machine Learning in python' Spring 2018.
These projects were built in a team of 3 in jupyter notebook using python 3 with Anaconda library.

The base code was provided by our professor 'Eric Larson' - https://github.com/eclarson
and was modified by us. Please check copyrights before you use these codes.

Every folder will have a PDF file which contains the problem statement 
along with our solution to that problem statement in ipynb ot html

Thanks for checking out my work. Enjoy!!
